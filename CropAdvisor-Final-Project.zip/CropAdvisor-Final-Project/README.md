# CropAdvisor - Crop Disease Query & Advisory Ticketing System

A complete Spring Boot + Thymeleaf + MySQL project for managing farmers, agricultural officers, regions and crop-disease advisory tickets.

## Features
- Clean responsive dashboard
- Farmer CRUD: add, view, edit, delete
- Officer CRUD: add, view, edit, delete
- Region CRUD: add, view, edit, delete
- Advisory Ticket CRUD: add, view, edit, delete
- Ticket status filter: All / Open / In Progress / Resolved
- Priority badges: High / Medium / Low
- Officer assignment and farmer/region mapping
- MySQL + Spring Data JPA
- REST CRUD endpoints for Postman
- Sample records inserted automatically on the first empty database startup

## Requirements
- Java 17 or later
- Maven 3.9+ (or Maven available in your IDE)
- MySQL Server 8.x
- IntelliJ IDEA / Eclipse / VS Code (optional)
- Postman (optional, for REST API testing)

## 1. Configure MySQL
Open `src/main/resources/application.properties` and change:

    spring.datasource.username=root
    spring.datasource.password=yourpassword

Use your real MySQL password.

The database name is `cropadvisor_db`. The JDBC URL contains `createDatabaseIfNotExist=true`, so MySQL can create it automatically when the credentials are correct.

If your MySQL setup does not allow that option, run this once in MySQL:

    CREATE DATABASE cropadvisor_db;

## 2. Run from the CORRECT folder
The folder containing `pom.xml` is the project root:

    CropAdvisor-Final-Project

Open Command Prompt in that folder and run:

    mvn clean install
    mvn spring-boot:run

Do NOT run Maven from a parent folder that does not contain `pom.xml`.

## 3. Open the website

    http://localhost:8080

You will see the CropAdvisor dashboard with sample data on the first startup.

## 4. Demonstrate CRUD in the browser

### Farmers
Dashboard -> Farmers -> Add Farmer
Example:
- Name: Rithani Farm
- Phone: 9876543210
- Email: rithani@example.com
- Village: Pollachi
- Region: Pollachi

Click Save Farmer.
Then use Edit and Delete in the table.

### Officers
Dashboard -> Officers -> Add Officer
Example:
- Name: Dr. Anitha Kumar
- Phone: 9000012345
- Specialization: Crop Disease Management
- Region: Pollachi

### Regions
Dashboard -> Regions -> Add Region
Example:
- Region Name: Udumalpet
- District: Tiruppur
- Description: Vegetable and coconut farming region

### Tickets
Dashboard -> Tickets -> Raise Ticket
Example:
- Issue Title: Brown spots on leaves
- Crop Name: Tomato
- Photo Reference: tomato-brown-spots.jpg
- Farmer: Rithani Farm
- Region: Pollachi
- Officer: Dr. Anitha Kumar
- Priority: High
- Status: Open
- Symptoms: Brown circular spots appearing on older leaves.
- Recommendation: Inspect for fungal disease and follow local agricultural guidance.

After saving, use Edit to change the status to In Progress or Resolved. Delete is also available.

## 5. REST API / Postman
Import:

    postman/CropAdvisor.postman_collection.json

Base URL:

    http://localhost:8080

Endpoints:

    GET     /api/farmers
    GET     /api/farmers/{id}
    POST    /api/farmers
    PUT     /api/farmers/{id}
    DELETE  /api/farmers/{id}

    GET     /api/officers
    POST    /api/officers
    PUT     /api/officers/{id}
    DELETE  /api/officers/{id}

    GET     /api/regions
    POST    /api/regions
    PUT     /api/regions/{id}
    DELETE  /api/regions/{id}

    GET     /api/tickets
    GET     /api/tickets/{id}
    POST    /api/tickets
    PUT     /api/tickets/{id}
    DELETE  /api/tickets/{id}

## Project structure

    src/main/java/com/cropadvisor
      CropAdvisorApplication.java
      controller/
      controller/api/
      model/
      repository/

    src/main/resources
      templates/
      static/css/style.css
      application.properties

## Important
If Maven says `there is no POM in this directory`, you are in the wrong folder. Run:

    dir pom.xml

If `pom.xml` is not shown, use `cd` until you are inside the folder containing it.

If Windows says Maven cannot clean `target`, stop any running Java process using the project, close the IDE run session, then delete `target` and run Maven again.
