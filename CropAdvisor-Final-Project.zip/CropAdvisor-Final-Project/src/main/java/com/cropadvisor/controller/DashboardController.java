package com.cropadvisor.controller;

import com.cropadvisor.repository.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {
    private final FarmerRepository farmers;
    private final OfficerRepository officers;
    private final RegionRepository regions;
    private final TicketRepository tickets;

    public DashboardController(FarmerRepository farmers, OfficerRepository officers,
                               RegionRepository regions, TicketRepository tickets) {
        this.farmers = farmers; this.officers = officers; this.regions = regions; this.tickets = tickets;
    }

    @GetMapping("/")
    public String dashboard(Model model) {
        model.addAttribute("farmerCount", farmers.count());
        model.addAttribute("officerCount", officers.count());
        model.addAttribute("regionCount", regions.count());
        model.addAttribute("ticketCount", tickets.count());
        model.addAttribute("openCount", tickets.findAll().stream().filter(t -> "OPEN".equals(t.getStatus())).count());
        model.addAttribute("inProgressCount", tickets.findAll().stream().filter(t -> "IN_PROGRESS".equals(t.getStatus())).count());
        model.addAttribute("resolvedCount", tickets.findAll().stream().filter(t -> "RESOLVED".equals(t.getStatus())).count());
        model.addAttribute("recentTickets", tickets.findAll(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC, "id")).stream().limit(5).toList());
        return "index";
    }
}
