package com.cropadvisor.controller;

import com.cropadvisor.model.Ticket;
import com.cropadvisor.repository.FarmerRepository;
import com.cropadvisor.repository.OfficerRepository;
import com.cropadvisor.repository.RegionRepository;
import com.cropadvisor.repository.TicketRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/tickets")
public class TicketController {
    private final TicketRepository repo; private final FarmerRepository farmers; private final OfficerRepository officers; private final RegionRepository regions;
    public TicketController(TicketRepository repo, FarmerRepository farmers, OfficerRepository officers, RegionRepository regions) { this.repo = repo; this.farmers = farmers; this.officers = officers; this.regions = regions; }
    @GetMapping public String list(@RequestParam(required=false) String status, Model model) {
        var all = repo.findAll();
        if (status != null && !status.isBlank()) all = all.stream().filter(t -> status.equals(t.getStatus())).toList();
        model.addAttribute("tickets", all); model.addAttribute("selectedStatus", status == null ? "" : status); return "tickets/list";
    }
    @GetMapping("/new") public String form(Model model) { loadForm(model, new Ticket()); return "tickets/form"; }
    @PostMapping("/save") public String save(@ModelAttribute Ticket ticket) { repo.save(ticket); return "redirect:/tickets"; }
    @GetMapping("/edit/{id}") public String edit(@PathVariable Long id, Model model) { loadForm(model, repo.findById(id).orElseThrow()); return "tickets/form"; }
    @GetMapping("/delete/{id}") public String delete(@PathVariable Long id) { repo.deleteById(id); return "redirect:/tickets"; }
    private void loadForm(Model model, Ticket ticket) { model.addAttribute("ticket", ticket); model.addAttribute("farmers", farmers.findAll()); model.addAttribute("officers", officers.findAll()); model.addAttribute("regions", regions.findAll()); }
}
