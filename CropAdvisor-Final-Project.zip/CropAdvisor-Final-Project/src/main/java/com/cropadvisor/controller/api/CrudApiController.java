package com.cropadvisor.controller.api;

import com.cropadvisor.model.*;
import com.cropadvisor.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class CrudApiController {
    private final FarmerRepository farmers; private final OfficerRepository officers; private final RegionRepository regions; private final TicketRepository tickets;
    public CrudApiController(FarmerRepository farmers, OfficerRepository officers, RegionRepository regions, TicketRepository tickets) { this.farmers=farmers; this.officers=officers; this.regions=regions; this.tickets=tickets; }

    @GetMapping("/farmers") public Object farmers() { return farmers.findAll(); }
    @GetMapping("/farmers/{id}") public ResponseEntity<Farmer> farmer(@PathVariable Long id) { return farmers.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping("/farmers") public Farmer farmerCreate(@RequestBody Farmer x) { return farmers.save(x); }
    @PutMapping("/farmers/{id}") public ResponseEntity<Farmer> farmerUpdate(@PathVariable Long id,@RequestBody Farmer x){return farmers.findById(id).map(old->{x.setId(id);return ResponseEntity.ok(farmers.save(x));}).orElse(ResponseEntity.notFound().build());}
    @DeleteMapping("/farmers/{id}") public ResponseEntity<Void> farmerDelete(@PathVariable Long id){if(!farmers.existsById(id))return ResponseEntity.notFound().build();farmers.deleteById(id);return ResponseEntity.noContent().build();}

    @GetMapping("/officers") public Object officers() { return officers.findAll(); }
    @GetMapping("/officers/{id}") public ResponseEntity<Officer> officer(@PathVariable Long id) { return officers.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping("/officers") public Officer officerCreate(@RequestBody Officer x) { return officers.save(x); }
    @PutMapping("/officers/{id}") public ResponseEntity<Officer> officerUpdate(@PathVariable Long id,@RequestBody Officer x){return officers.findById(id).map(old->{x.setId(id);return ResponseEntity.ok(officers.save(x));}).orElse(ResponseEntity.notFound().build());}
    @DeleteMapping("/officers/{id}") public ResponseEntity<Void> officerDelete(@PathVariable Long id){if(!officers.existsById(id))return ResponseEntity.notFound().build();officers.deleteById(id);return ResponseEntity.noContent().build();}

    @GetMapping("/regions") public Object regions() { return regions.findAll(); }
    @GetMapping("/regions/{id}") public ResponseEntity<Region> region(@PathVariable Long id) { return regions.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping("/regions") public Region regionCreate(@RequestBody Region x) { return regions.save(x); }
    @PutMapping("/regions/{id}") public ResponseEntity<Region> regionUpdate(@PathVariable Long id,@RequestBody Region x){return regions.findById(id).map(old->{x.setId(id);return ResponseEntity.ok(regions.save(x));}).orElse(ResponseEntity.notFound().build());}
    @DeleteMapping("/regions/{id}") public ResponseEntity<Void> regionDelete(@PathVariable Long id){if(!regions.existsById(id))return ResponseEntity.notFound().build();regions.deleteById(id);return ResponseEntity.noContent().build();}

    @GetMapping("/tickets") public Object tickets() { return tickets.findAll(); }
    @GetMapping("/tickets/{id}") public ResponseEntity<Ticket> ticket(@PathVariable Long id) { return tickets.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping("/tickets") public Ticket ticketCreate(@RequestBody Ticket x) { return tickets.save(x); }
    @PutMapping("/tickets/{id}") public ResponseEntity<Ticket> ticketUpdate(@PathVariable Long id,@RequestBody Ticket x){return tickets.findById(id).map(old->{x.setId(id);return ResponseEntity.ok(tickets.save(x));}).orElse(ResponseEntity.notFound().build());}
    @DeleteMapping("/tickets/{id}") public ResponseEntity<Void> ticketDelete(@PathVariable Long id){if(!tickets.existsById(id))return ResponseEntity.notFound().build();tickets.deleteById(id);return ResponseEntity.noContent().build();}
}
