package com.cropadvisor.controller;

import com.cropadvisor.model.Region;
import com.cropadvisor.repository.RegionRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/regions")
public class RegionController {
    private final RegionRepository repo;
    public RegionController(RegionRepository repo) { this.repo = repo; }
    @GetMapping public String list(Model model) { model.addAttribute("regions", repo.findAll()); return "regions/list"; }
    @GetMapping("/new") public String form(Model model) { model.addAttribute("region", new Region()); return "regions/form"; }
    @PostMapping("/save") public String save(@ModelAttribute Region region) { repo.save(region); return "redirect:/regions"; }
    @GetMapping("/edit/{id}") public String edit(@PathVariable Long id, Model model) { model.addAttribute("region", repo.findById(id).orElseThrow()); return "regions/form"; }
    @GetMapping("/delete/{id}") public String delete(@PathVariable Long id) { repo.deleteById(id); return "redirect:/regions"; }
}
