package com.cropadvisor.controller;

import com.cropadvisor.model.Officer;
import com.cropadvisor.repository.OfficerRepository;
import com.cropadvisor.repository.RegionRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/officers")
public class OfficerController {
    private final OfficerRepository repo; private final RegionRepository regions;
    public OfficerController(OfficerRepository repo, RegionRepository regions) { this.repo = repo; this.regions = regions; }
    @GetMapping public String list(Model model) { model.addAttribute("officers", repo.findAll()); return "officers/list"; }
    @GetMapping("/new") public String form(Model model) { model.addAttribute("officer", new Officer()); model.addAttribute("regions", regions.findAll()); return "officers/form"; }
    @PostMapping("/save") public String save(@ModelAttribute Officer officer) { repo.save(officer); return "redirect:/officers"; }
    @GetMapping("/edit/{id}") public String edit(@PathVariable Long id, Model model) { model.addAttribute("officer", repo.findById(id).orElseThrow()); model.addAttribute("regions", regions.findAll()); return "officers/form"; }
    @GetMapping("/delete/{id}") public String delete(@PathVariable Long id) { repo.deleteById(id); return "redirect:/officers"; }
}
