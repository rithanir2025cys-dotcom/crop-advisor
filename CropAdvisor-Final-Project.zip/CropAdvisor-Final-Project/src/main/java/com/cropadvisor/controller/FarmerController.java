package com.cropadvisor.controller;

import com.cropadvisor.model.Farmer;
import com.cropadvisor.repository.FarmerRepository;
import com.cropadvisor.repository.RegionRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/farmers")
public class FarmerController {
    private final FarmerRepository repo; private final RegionRepository regions;
    public FarmerController(FarmerRepository repo, RegionRepository regions) { this.repo = repo; this.regions = regions; }

    @GetMapping public String list(Model model) { model.addAttribute("farmers", repo.findAll()); return "farmers/list"; }
    @GetMapping("/new") public String form(Model model) { model.addAttribute("farmer", new Farmer()); model.addAttribute("regions", regions.findAll()); return "farmers/form"; }
    @PostMapping("/save") public String save(@ModelAttribute Farmer farmer) { repo.save(farmer); return "redirect:/farmers"; }
    @GetMapping("/edit/{id}") public String edit(@PathVariable Long id, Model model) { model.addAttribute("farmer", repo.findById(id).orElseThrow()); model.addAttribute("regions", regions.findAll()); return "farmers/form"; }
    @GetMapping("/delete/{id}") public String delete(@PathVariable Long id) { repo.deleteById(id); return "redirect:/farmers"; }
}
