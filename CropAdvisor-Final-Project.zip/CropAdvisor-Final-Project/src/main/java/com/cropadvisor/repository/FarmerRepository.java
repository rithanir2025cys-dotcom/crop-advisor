package com.cropadvisor.repository;

import com.cropadvisor.model.Farmer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FarmerRepository extends JpaRepository<Farmer, Long> { }
