package com.cropadvisor.repository;

import com.cropadvisor.model.Officer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OfficerRepository extends JpaRepository<Officer, Long> { }
