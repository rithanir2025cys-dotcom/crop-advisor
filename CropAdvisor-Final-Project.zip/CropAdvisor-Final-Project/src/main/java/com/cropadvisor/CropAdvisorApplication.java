package com.cropadvisor;

import com.cropadvisor.model.Farmer;
import com.cropadvisor.model.Officer;
import com.cropadvisor.model.Region;
import com.cropadvisor.model.Ticket;
import com.cropadvisor.repository.FarmerRepository;
import com.cropadvisor.repository.OfficerRepository;
import com.cropadvisor.repository.RegionRepository;
import com.cropadvisor.repository.TicketRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CropAdvisorApplication {
    public static void main(String[] args) {
        SpringApplication.run(CropAdvisorApplication.class, args);
    }

    @Bean
    CommandLineRunner seedData(RegionRepository regions, FarmerRepository farmers,
                               OfficerRepository officers, TicketRepository tickets) {
        return args -> {
            if (regions.count() == 0) {
                Region r1 = new Region();
                r1.setName("Coimbatore North");
                r1.setDistrict("Coimbatore");
                r1.setDescription("Northern agricultural belt");
                regions.save(r1);

                Region r2 = new Region();
                r2.setName("Pollachi");
                r2.setDistrict("Coimbatore");
                r2.setDescription("Coconut and vegetable farming region");
                regions.save(r2);

                Farmer f1 = new Farmer();
                f1.setName("Arun Kumar");
                f1.setPhone("9876543210");
                f1.setEmail("arun@example.com");
                f1.setVillage("Karamadai");
                f1.setRegion(r1);
                farmers.save(f1);

                Farmer f2 = new Farmer();
                f2.setName("Meena Devi");
                f2.setPhone("9876501234");
                f2.setEmail("meena@example.com");
                f2.setVillage("Pollachi");
                f2.setRegion(r2);
                farmers.save(f2);

                Officer o1 = new Officer();
                o1.setName("Dr. Priya Nair");
                o1.setPhone("9000011111");
                o1.setSpecialization("Crop Disease Management");
                o1.setRegion(r1);
                officers.save(o1);

                Officer o2 = new Officer();
                o2.setName("Karthik Raj");
                o2.setPhone("9000022222");
                o2.setSpecialization("Pest and Soil Advisory");
                o2.setRegion(r2);
                officers.save(o2);

                Ticket t1 = new Ticket();
                t1.setTitle("Yellow spots on leaves");
                t1.setCropName("Tomato");
                t1.setSymptoms("Small yellow spots spreading across older leaves");
                t1.setPriority("HIGH");
                t1.setStatus("OPEN");
                t1.setRecommendation("Inspect for fungal infection and avoid overhead irrigation.");
                t1.setPhotoReference("tomato-leaf-01.jpg");
                t1.setFarmer(f1);
                t1.setOfficer(o1);
                t1.setRegion(r1);
                tickets.save(t1);

                Ticket t2 = new Ticket();
                t2.setTitle("White powder on leaves");
                t2.setCropName("Cucumber");
                t2.setSymptoms("White powder-like growth on leaf surface");
                t2.setPriority("MEDIUM");
                t2.setStatus("IN_PROGRESS");
                t2.setRecommendation("Improve airflow and follow a locally approved fungicide schedule.");
                t2.setPhotoReference("cucumber-powdery.jpg");
                t2.setFarmer(f2);
                t2.setOfficer(o2);
                t2.setRegion(r2);
                tickets.save(t2);

                Ticket t3 = new Ticket();
                t3.setTitle("Leaf curling and insect attack");
                t3.setCropName("Chilli");
                t3.setSymptoms("Leaves curling with visible small insects underneath");
                t3.setPriority("LOW");
                t3.setStatus("RESOLVED");
                t3.setRecommendation("Monitor aphid population and use an integrated pest management approach.");
                t3.setPhotoReference("chilli-aphid.jpg");
                t3.setFarmer(f2);
                t3.setOfficer(o2);
                t3.setRegion(r2);
                tickets.save(t3);
            }
        };
    }
}
