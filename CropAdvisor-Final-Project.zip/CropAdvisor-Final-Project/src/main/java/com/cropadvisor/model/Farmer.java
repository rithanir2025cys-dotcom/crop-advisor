package com.cropadvisor.model;

import jakarta.persistence.*;

@Entity
@Table(name = "farmers")
public class Farmer {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String name;
    private String phone;
    private String email;
    private String village;
    @ManyToOne
    @JoinColumn(name = "region_id")
    private Region region;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }
    public Region getRegion() { return region; }
    public void setRegion(Region region) { this.region = region; }
}
