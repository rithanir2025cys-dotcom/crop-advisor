package com.cropadvisor.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tickets")
public class Ticket {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String title;
    @Column(nullable = false)
    private String cropName;
    @Column(length = 2000)
    private String symptoms;
    private String priority;
    private String status;
    @Column(length = 2000)
    private String recommendation;
    private String photoReference;
    private LocalDateTime createdAt;

    @ManyToOne
    @JoinColumn(name = "farmer_id")
    private Farmer farmer;
    @ManyToOne
    @JoinColumn(name = "officer_id")
    private Officer officer;
    @ManyToOne
    @JoinColumn(name = "region_id")
    private Region region;

    @PrePersist
    public void onCreate() { if (createdAt == null) createdAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getCropName() { return cropName; }
    public void setCropName(String cropName) { this.cropName = cropName; }
    public String getSymptoms() { return symptoms; }
    public void setSymptoms(String symptoms) { this.symptoms = symptoms; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getRecommendation() { return recommendation; }
    public void setRecommendation(String recommendation) { this.recommendation = recommendation; }
    public String getPhotoReference() { return photoReference; }
    public void setPhotoReference(String photoReference) { this.photoReference = photoReference; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public Farmer getFarmer() { return farmer; }
    public void setFarmer(Farmer farmer) { this.farmer = farmer; }
    public Officer getOfficer() { return officer; }
    public void setOfficer(Officer officer) { this.officer = officer; }
    public Region getRegion() { return region; }
    public void setRegion(Region region) { this.region = region; }
}
